package com.isolutions4u.onlineshopping.dao;

import com.isolutions4u.onlineshopping.model.Product;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    private static Connection getConnection() throws SQLException {
        // Modify with your database connection details
        String url = "jdbc:mysql://localhost:3306/yourdatabase";
        String user = "yourusername";
        String password = "yourpassword";
        return DriverManager.getConnection(url, user, password);
    }

    public static void incrementViewCount(int productId) {
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("UPDATE product SET views = views + 1 WHERE id = ?")) {
            ps.setInt(1, productId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void incrementPurchaseCount(int productId) {
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("UPDATE product SET purchases = purchases + 1 WHERE id = ?")) {
            ps.setInt(1, productId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Product> getMostViewedProducts() {
        List<Product> products = new ArrayList<>();
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM product ORDER BY views DESC LIMIT 3")) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                products.add(mapRowToProduct(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    public static List<Product> getMostPurchasedProducts() {
        List<Product> products = new ArrayList<>();
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM product ORDER BY purchases DESC LIMIT 3")) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                products.add(mapRowToProduct(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    public static Product getProductById(int productId) {
        Product product = null;
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM product WHERE id = ?")) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                product = mapRowToProduct(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return product;
    }

    private static Product mapRowToProduct(ResultSet rs) throws SQLException {
        Product product = new Product();
        product.setId(rs.getInt("id"));
        product.setName(rs.getString("name"));
        product.setBrand(rs.getString("brand"));
        product.setDescription(rs.getString("description"));
        product.setUnitPrice(rs.getDouble("unit_price"));
        product.setQuantity(rs.getInt("quantity"));
        product.setActive(rs.getBoolean("is_active"));
        product.setCategoryId(rs.getInt("category_id"));
        product.setSupplierId(rs.getInt("supplier_id"));
        product.setPurchases(rs.getInt("purchases"));
        product.setViews(rs.getInt("views"));
        product.setCode(rs.getString("code"));
        return product;
    }
}